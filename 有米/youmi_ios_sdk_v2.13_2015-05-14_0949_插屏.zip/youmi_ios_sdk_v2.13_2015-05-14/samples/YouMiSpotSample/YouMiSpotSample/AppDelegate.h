//
//  AppDelegate.h
//  YouMiSpotSample
//
//  Created by 陈建峰 on 14-7-11.
//  Copyright (c) 2014年 陈建峰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
