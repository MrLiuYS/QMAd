//
//  MyView.h
//  Unity-iPhone
//
//  Created by YANG ENZO on 13-1-10.
//
//

#import <Foundation/Foundation.h>

@interface UnityHandlerMiddle : NSObject

@end
